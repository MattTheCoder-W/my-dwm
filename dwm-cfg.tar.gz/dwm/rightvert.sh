#!/bin/sh
xrandr --output HDMI-A-0 --primary --mode 1920x1080 --rate 165 --rotate normal 
