#!/usr/bin/env python3
from PIL import Image, ImageFont, ImageDraw
import os
from datetime import datetime
import time


def get_font_size(font, text):
    return font.getsize(text)


birth = datetime(2022, 4, 6)
to_birth = (birth - datetime.now()).total_seconds()
hours = int(to_birth//3600)
to_birth -= hours*3600
minutes = int(to_birth//60)
hours, minutes = (str(hours).zfill(2), str(minutes).zfill(2))
time_str = f"{hours}:{minutes}"

img = Image.new("RGB", (1920, 1080), (56, 59, 74))
draw = ImageDraw.Draw(img)
font = ImageFont.truetype("/home/m4t1/.config/dwm/birthday-wallpaper/PressStart2P-Regular.ttf", 100)
text = time_str
size = get_font_size(font, text)  # (width, height)
pos = (1920//2 - size[0]//2, 1080//2 - size[1]//2)
draw.text(pos, text, (255, 255, 255), font=font)

img.save("/home/m4t1/.config/dwm/wallpapers/birthday.png")

